/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloconection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;



public class conexaobd {
    
    //o Modelo conexão vai ser responsável por fazer a conexão com o banco de dados
    
    public Statement stm; //variável por realizar as pesquisas no banco de dados
    public ResultSet rs; //variável responsával por armazenar o resultado da pesquisa 
    private String driver = "org.postgresql.Driver"; //reponsável por indentificar o serviço de banco de dados
    private String url="jdbc:postgresql://localhost:5432/projetojava"; //reponsável pelo caminho aonde esta o banco de dados
    private String usuario = "postgres";
    private String senha = "java1";
    public Connection con; //variável responsável pela conexão com o banco de dados
    
    public void conexao(){ //metodo responsável por fazer a conexão 
        
        try {
            System.setProperty("jdbc.Drivers", driver);
            con=DriverManager.getConnection(url, usuario, senha);
            //JOptionPane.showMessageDialog(null, "Conexão Efetuada com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao se conectar com o banco de dados!:\n"+ex.getMessage());
        }
        
    }
    
    public void executaSql(String sql){ //metodo responsável para fazer a execução no banco de dados
        try {
            stm = con.createStatement(rs.TYPE_SCROLL_INSENSITIVE,rs.CONCUR_READ_ONLY);
            rs = stm.executeQuery(sql);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ExecutaSql:\n"+ex.getMessage());
        }
    }
    
    public void desconecta(){ //metodo responsável por se Desconectar com o bando de dados
        try {
            con.close();
            //JOptionPane.showMessageDialog(null, "Desconectado com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao fechar conexão com o banco de dados:\n"+ex.getMessage());
        }
    }
    
}
