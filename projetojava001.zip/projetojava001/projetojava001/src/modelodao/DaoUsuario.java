/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelodao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import modeloBeans.BeansUsuario;
import modeloBeans.Beanscoordenador;
import modeloconection.conexaobd;



public class DaoUsuario {
    
    //Método responsável por fazer a inserção de salvar, editar, excluir, buscar, e updates 
    
    conexaobd conex = new conexaobd();
    BeansUsuario mod = new BeansUsuario();
    
    public void salvar(BeansUsuario mod){
        
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into gestao(gest_nome,gest_senha,gest_tipo) values(?,?,?)");
            pst.setString(1,mod.getGestNome());
            pst.setString(2,mod.getGestSenha());
            pst.setString(3,mod.getGestTipo());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Usuário inseridos com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao inserir Usuário/nErro:"+ex);
        }
        
        
        
        conex.desconecta();
        
        
        
    }
    public void Alterar(BeansUsuario mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("update gestao set gest_nome=?,gest_senha=?,gest_tipo=? where gest_cod=?");
            pst.setString(1, mod.getGestNome());
            pst.setString(2, mod.getGestSenha());
            pst.setString(3, mod.getGestTipo());
            pst.setInt(4, mod.getGestCod());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário alterados com Sucesso");
            
            
                    
                    } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na alteração do Usuário/nErro:"+ex);
        }
        
        conex.desconecta();
    }
    
    
    public BeansUsuario buscaUsuario(BeansUsuario mod){
        conex.conexao();
        conex.executaSql("select *from gestao where gest_nome like'%"+mod.getGestPesquisa()+"%'");
        try {
            conex.rs.first();
            mod.setGestCod(conex.rs.getInt("gest_cod"));
            mod.setGestNome(conex.rs.getString("gest_nome"));
            mod.setGestSenha(conex.rs.getString("gest_senha"));
            mod.setGestTipo(conex.rs.getString("gest_tipo"));
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Usuário não cadastrado:");
        }
        
        conex.desconecta();
        return mod;
        
        
    }
    
    public void Excluir(BeansUsuario mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from gestao where gest_cod=?");
            pst.setInt(1, mod.getGestCod());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário excluidos com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir Usuário/nErro:"+ex);
            
            
        }
        
        
        conex.desconecta();
    }
    
    
}
