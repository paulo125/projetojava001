/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelodao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansUSUarios;
import modeloconection.conexaobd;

/**
 *
 * @author Paulo
 */
public class DaoUsuarios {
    
    //Método responsável por fazer a inserção de salvar, editar, excluir, buscar, e updates 
    //BeansUSUarios usu = new BeansUSUarios();
    conexaobd conexBairro = new conexaobd();
    String nomeBairro;
    conexaobd conex = new  conexaobd();
    int codBai;
     
    
        public void Salvar(BeansUSUarios usu){
        buscaBaicod(usu.getNomeBairro());
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into usuarios(usu_nome,usu_mat,usu_tele,usu_rua,usu_cep,usu_completmento,usu_baicodigo,usu_data) values(?,?,?,?,?,?,?,?)");
            pst.setString(1,usu.getNomeUsu());
            pst.setString(2,usu.getMata());
            pst.setString(3,usu.getTele());
            pst.setString(4,usu.getRua());
            pst.setString(5,usu.getCep());
            pst.setString(6,usu.getComplemento());
            pst.setInt(7, codBai);
            pst.setString(8,usu.getData());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Formulario de Usuário salvo com Sucesso");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao salvar formulario"+ex);
        }
        conex.desconecta();
        
    }
    
        
        public void Alterar(BeansUSUarios usu){
        buscaBaicod(usu.getNomeBairro());
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.con.prepareStatement("update usuarios set usu_nome=?, usu_mat=?, usu_tele=?, usu_rua=?, usu_cep=?, usu_completmento=?, usu_baicodigo=?, usu_data=? where usu_cod=?");
            pst.setString(1,usu.getNomeUsu());
            pst.setString(2,usu.getMata());
            pst.setString(3,usu.getTele());
            pst.setString(4,usu.getRua());
            pst.setString(5,usu.getCep());
            pst.setString(6,usu.getComplemento());
            pst.setInt(7, codBai);
            pst.setString(8,usu.getData());
            pst.setInt(9, usu.getCodUsu());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Formulario alterado com Sucesso");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao alterar formulario"+ex);
        }
        conex.desconecta();
        
    }
    
    
    
    public void buscaBaicod(String nome){
        conex.conexao();
        conex.executaSql("select *from bairro where bainome ='"+nome+"'");
        try {
            conex.rs.first();
            codBai=conex.rs.getInt("baicodigo");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao buscar bairro"+ex);
        }
         conex.desconecta();
        
    }
    
    public  BeansUSUarios buscaUSUarios(BeansUSUarios usu){
        conex.conexao();
        
        try {
            // "select *from pacientes where lower (paci_nome) like lower('%"+pac.getPesquisa()+"%')"
            conex.executaSql("select *from usuarios where (usu_nome) like'%"+usu.getPesquisa()+"%'");
            conex.rs.first();
            buscaNomeBairro(conex.rs.getInt("usu_baicodigo"));
            usu.setNomeUsu(conex.rs.getString("usu_nome"));
            usu.setCep(conex.rs.getString("usu_cep"));
            usu.setCodUsu(conex.rs.getInt("usu_cod"));
            usu.setComplemento(conex.rs.getString("usu_completmento"));
            usu.setData(conex.rs.getString("usu_data"));
            usu.setMata(conex.rs.getString("usu_mat"));
            usu.setTele(conex.rs.getString("usu_tele"));
            usu.setRua(conex.rs.getString("usu_rua"));
            usu.setNomeBairro(nomeBairro);
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar Usuarios"+ex);
        }
        
        
        conex.desconecta();
        
        return usu;
    }
    
    public void buscaNomeBairro(int cod){
        conexBairro.conexao();
        
        try {
            conexBairro.executaSql("select *from bairro where baicodigo="+cod);
            conexBairro.rs.first();
            nomeBairro = conexBairro.rs.getString("bainome");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao buscar nome Bairro"+ex);
        }
        
        conexBairro.desconecta();
        
    }
    
    public void Excluir(BeansUSUarios usu){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from usuarios where usu_cod=?");
            pst.setInt(1, usu.getCodUsu());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Usuário Excluido com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao Excluir Usuario"+ex);
        }
        conex.desconecta();
    }
}
