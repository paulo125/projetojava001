/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelodao;

import modeloconection.conexaobd;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.Beanscoordenador;




public class daocoordenador {
    
    //Método responsável por fazer a inserção de salvar, editar, excluir, buscar, e updates 
    
    conexaobd conex = new conexaobd();
    Beanscoordenador mod = new Beanscoordenador();
    
    public void salvar(Beanscoordenador mod){
        
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into coordenadores(nome_coordenador,turno_coordenador,telefone_coordenador) values(?,?,?)");
            pst.setString(1,mod.getNome());
            pst.setString(2,mod.getTurno());
            pst.setInt(3,mod.getTelefone());
            pst.execute();
            JOptionPane.showMessageDialog(null,"Dados inseridos com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao inserir os Dados/nErro:"+ex);
        }
        
        
        
        conex.desconecta();
        
        
        
    }
    
    
    
    public void Editar(Beanscoordenador mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("update coordenadores set nome_coordenador=?,turno_coordenador=?,telefone_coordenador=? where cod_coordenador=?");
            pst.setString(1, mod.getNome());
            pst.setString(2, mod.getTurno());
            pst.setInt(3, mod.getTelefone());
            pst.setInt(4, mod.getCodico());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados alterados com Sucesso");
            
            
                    
                    } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro na alteração dos dados/nErro:"+ex);
        }
        
        conex.desconecta();
    }
    
    public void Excluir(Beanscoordenador mod){
        conex.conexao();
        try {
            PreparedStatement pst = conex.con.prepareStatement("delete from coordenadores where cod_coordenador=?");
            pst.setInt(1, mod.getCodico());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Dados excluidos com Sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao excluir dados/nErro:"+ex);
            
            
        }
        
        
        conex.desconecta();
    }
    
    public Beanscoordenador buscacoordenador(Beanscoordenador mod){
        conex.conexao();
        conex.executaSql("select *from coordenadores where nome_coordenador like'%"+mod.getPesquisas()+"%'");
        try {
            conex.rs.first();
            mod.setCodico(conex.rs.getInt("cod_coordenador"));
            mod.setNome(conex.rs.getString("nome_coordenador"));
            mod.setTurno(conex.rs.getString("turno_coordenador"));
            mod.setTelefone(conex.rs.getInt("telefone_coordenador"));
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Coordenador não cadastrado:");
        }
        
        conex.desconecta();
        return mod;
        
        
    } 
}
