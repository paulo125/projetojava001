/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelodao;

import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import modeloBeans.BeansAgenda;
import modeloconection.conexaobd;

/**
 *
 * @author Paulo
 */
public class DaoAgenda {
    
    //Método responsável por fazer a inserção de salvar, editar, excluir, buscar, e updates 
    
    BeansAgenda agenda = new BeansAgenda();
    conexaobd conex = new conexaobd();
    conexaobd conexUsuario = new conexaobd();
    conexaobd conexCoordenador = new conexaobd();
    int codCoord;
    int codusu;
    
    public void Salvar(BeansAgenda agenda){
        Buscarcoordenador(agenda.getNomeCoord());
        Buscarusuario(agenda.getNomeusu());
        conex.conexao();
        

        try {
            PreparedStatement pst = conex.con.prepareStatement("insert into agenda (agenda_codusu,agenda_codcoordenador,agenda_motivo,\"agenda_presença\",agenda_data,agenda_status)values(?,?,?,?,?,?)");
            pst.setInt(1, codusu);
            pst.setInt(2, codCoord);
            pst.setString(3, agenda.getMotivo());
            pst.setString(4, agenda.getPresença());
            pst.setDate(5, new java.sql.Date(agenda.getData().getTime()));
            pst.setString(6, agenda.getStatus());
            pst.execute();
            JOptionPane.showMessageDialog(null, "Reunião Salva com sucesso");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Erro ao salvar Reunião"+ex);
        }
        conex.desconecta();
        
    }
    
    public void Buscarcoordenador(String nomeCoordenador){
        conexCoordenador.conexao();
        conexCoordenador.executaSql("select *from coordenadores where nome_coordenador='"+nomeCoordenador+"'");
        try {
            conexCoordenador.rs.first();
            codCoord= conexCoordenador.rs.getInt("cod_coordenador");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Coordenador não encontrado");
        }
        
        
    }
    
    public void Buscarusuario(String nomeUsuario){
        conexUsuario.conexao();
        conexUsuario.executaSql("select *from usuarios where usu_nome='"+nomeUsuario+"'");
        try {
            conexUsuario.rs.first();
            codusu= conexUsuario.rs.getInt("usu_cod");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Usuario não encontrado");
        }
        
    }
    
    public void Alterar(BeansAgenda agenda){
        conex.conexao();
        
        try {
            PreparedStatement pst = conex.con.prepareStatement("update agenda set agenda_status=? where agenda_cod=?");
            pst.setString(1,agenda.getStatus());
            pst.setInt(2,agenda.getAgendaCod());
            
            pst.execute();
            JOptionPane.showMessageDialog(null,"Reunição Finalizada");
            
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null,"Erro ao Finalizar o atendimento"+ex);
        }
        conex.desconecta();
        
        
    }
}
