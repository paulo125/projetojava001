/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloBeans;



public class BeansUsuario {
    //Modelo beans é respondavel por cria a nossa classe
    //responsáavel para desclarar a classe
    //responsável por criar os atributos e
    //encapsular 
    
    private Integer gestCod;
    private String gestNome;
    private String gestTipo;
    private String gestSenha;
    private String gestPesquisa;

    public String getGestPesquisa() {
        return gestPesquisa;
    }

    public void setGestPesquisa(String gestPesquisa) {
        this.gestPesquisa = gestPesquisa;
    }

    public Integer getGestCod() {
        return gestCod;
    }

    public void setGestCod(Integer gestCod) {
        this.gestCod = gestCod;
    }

    public String getGestNome() {
        return gestNome;
    }

    public void setGestNome(String gestNome) {
        this.gestNome = gestNome;
    }

    public String getGestTipo() {
        return gestTipo;
    }

    public void setGestTipo(String gestTipo) {
        this.gestTipo = gestTipo;
    }

    public String getGestSenha() {
        return gestSenha;
    }

    public void setGestSenha(String gestSenha) {
        this.gestSenha = gestSenha;
    }

    public void getGestCod(int parseInt) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
