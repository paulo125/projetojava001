/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modeloBeans;




public class Beanscoordenador {
    //Modelo beans é respondavel por cria a nossa classe
    //responsáavel para desclarar a classe
    //responsável por criar os atributos e
    //encapsular 
    
    
    /**
     * @return the pesquisas
     */
    public String getPesquisas() {
        return pesquisas;
    }

    /**
     * @param pesquisas the pesquisas to set
     */
    public void setPesquisas(String pesquisas) {
        this.pesquisas = pesquisas;
    }

    /**
     * @return the codico
     */
    public int getCodico() {
        return codico;
    }

    /**
     * @param codico the codico to set
     */
    public void setCodico(int codico) {
        this.codico = codico;
    }

    /**
     * @return the nome
     */
    public String getNome() {
        return nome;
    }

    /**
     * @param nome the nome to set
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * @return the turno
     */
    public String getTurno() {
        return turno;
    }

    /**
     * @param turno the turno to set
     */
    public void setTurno(String turno) {
        this.turno = turno;
    }

    /**
     * @return the telefone
     */
    public int getTelefone() {
        return telefone;
    }

    /**
     * @param telefone the telefone to set
     */
    public void setTelefone(int telefone) {
        this.telefone = telefone;
    }
    
    private int codico;
    private String nome;
    private String turno;
    private int telefone;
    private String pesquisas;
        
    
}
